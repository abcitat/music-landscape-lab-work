package MusicLandscape.container;

import java.util.*;

import MusicLandscape.entities.Track;
import MusicLandscape.util.MyMatcher;

public class MyTrackContainer {
	private java.util.List<Track> selection=new ArrayList<Track>();
	private java.util.Set <Track> tracks=new HashSet<Track>();
	
	public MyTrackContainer(){
	}
	
	public MyTrackContainer(Track[] t) {			
		for (Track x:t) {
			tracks.add(x);
		}
	
		selection.addAll(tracks);
	}
	
	public MyTrackContainer(Iterable<Track> t) {
		for (Track x: t) {
			tracks.add(x);
		}
		selection.addAll(tracks);
	}

	public void sort(java.util.Comparator<Track> theComp, boolean asc) {
		if (asc==true)
			Collections.sort(selection, theComp);
		else 
			Collections.sort(selection, theComp.reversed());
	}
	
	public int filter(MyMatcher<Track> matcher) {
		int count=0;
		for(ListIterator<Track> it=selection.listIterator();it.hasNext();){
			if (!matcher.matches(it.next())) {
				it.remove();
				count++;
			}
		}
		return count;
	}
	
	public void reset() {
		selection.clear();
		selection.addAll(tracks);
	}
	
	public int remove() {
		int num_removed=selection.size();
		tracks.removeAll(selection);
		reset();
		return num_removed;
	}
	
	public int addAll(Track[] t) {
		int num_added=Arrays.asList(t).size();
		tracks.addAll(Arrays.asList(t));
		return num_added;
	}
	
	public int size() {
		return tracks.size();
	}
	
	public Track[] selection() {
		return selection.toArray(new Track[selection.size()]);
	}
	
	public boolean add(Track t) {
		if (t==null)
			return false;
		return tracks.add(t);
	}
	

	public Set<Track> showTracks(){
		return tracks;
	}
	
	public void printTracks(){		
		if(tracks.size() != 0){	
			System.out.print("\nTracks in this data base: \n");			
			int count = 0;			
			for(Track x : tracks){
				if(x !=null){
					System.out.printf("[%03d] "+x.getString()+"\n", count);			
				}count++;
			}		
		}			
	}
	
	public boolean hasTrack(int index){		
		if(index >= 0 && index < tracks.size()) { 
			List<Track> tempList = new ArrayList<Track>(tracks);				
			if(tempList.get(index).scan()){
				return true;
			}
			return false;
		}
		return false;				
	}
	
	public void removeFromSelection(Track t){		
		if(t!=null){
			selection.remove(t);
		}				
	}
	
	public void addToSelection(Track t){		
		if(t != null){
			selection.add(t);
		}	
	}
	
	

}
