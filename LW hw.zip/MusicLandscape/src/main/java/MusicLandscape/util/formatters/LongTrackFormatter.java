package MusicLandscape.util.formatters;

import MusicLandscape.entities.Track;
import MusicLandscape.util.MyFormatter;

public class LongTrackFormatter implements MyFormatter<Track> {

	@Override
	public String header() {
		return String.format("[Title     Writer    (min:sec)]");
	}

	@Override
	public String format(Track t) {
		return String.format(
				"%-10.10s %-10.10s (%02d:%02d)",
				t.getTitle(),
				t.getWriter(),
				t.getDuration()/60,
				t.getDuration() % 60
				);
	}

	@Override
	public String topSeparator() {
		return "-------------------------------";
	}

	@Override
	public String toString() {
		return "Long format [Title, Writer (min:sec)]";

	}
}
