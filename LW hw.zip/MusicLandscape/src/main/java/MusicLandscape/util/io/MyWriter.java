package MusicLandscape.util.io;


import java.io.FileWriter;
import java.io.IOException;

import MusicLandscape.util.MyFormatter;


public class MyWriter<T> {

	protected FileWriter out;
	private MyFormatter<T> theFormat;


	public MyWriter(FileWriter file, MyFormatter<T> theFormat) {
		if (file == null)
			throw new IllegalArgumentException("expected non-null FileWriter");
		this.out=file;
		
		if (theFormat == null)
			throw new IllegalArgumentException("expected non-null MyFormatter");
		this.theFormat=theFormat;
		
	}


	public final boolean put(T t) {
		try {
			out.write(String.format("%s\n",theFormat.format(t)));
			return true;
		}	
		catch (IOException e) {
			e.printStackTrace();
			return false;	
		}
					
	}

	public void close() throws java.io.IOException{
		out.close();
	};
	
}
