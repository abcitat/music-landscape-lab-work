package MusicLandscape.util.io;

import java.io.*;

import MusicLandscape.entities.Artist;
import MusicLandscape.entities.Track;

public class MyTrackCSVReader extends MyReader<Track> {
	
	private static final int TITLE=0;
	private static final int WRITER=1;
	private static final int PERFORMER=2;
	private static final int DURATION=3;
	private static final int YEAR=4;
	

	public MyTrackCSVReader(java.io.BufferedReader in) {
		super(in);
	}

	@Override
	public Track get(){
		
		Track newTrack = null;
		String line=null;
		try {
			line=in.readLine();
			if (line!=null) { 
				String[] x=line.split(", ?");
				newTrack=new Track();
				newTrack.setTitle(x[0]);
				newTrack.setWriter(new Artist(x[1]));
				newTrack.setPerformer(new Artist(x[2]));
				newTrack.setDuration(Integer.parseInt(x[3]));
				newTrack.setYear(Integer.parseInt(x[4]));
				//newTrack.toString();
			} 
		
		} catch (RuntimeException e) {
			System.out.printf(line + "Error parsing.");
			e.printStackTrace();
			return null;
			
		} catch (IOException e) {			
			System.out.printf("Error reading.");
			e.printStackTrace();
			return null;
		}
		return newTrack;
	}

}
