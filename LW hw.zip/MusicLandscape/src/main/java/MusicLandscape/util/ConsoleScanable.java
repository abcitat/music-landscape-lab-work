package MusicLandscape.util;

public interface ConsoleScanable{
	public boolean scan();
}
