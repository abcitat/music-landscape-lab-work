package MusicLandscape.util.comparators;

import java.util.Comparator;

import MusicLandscape.entities.Track;

public class YearComparator implements Comparator<Track> {

	@Override
	public int compare(Track t1, Track t2) {
		return t1.getYear()-t2.getYear();
	}
	
	public String toString() {
		return "by year";
	}

}
