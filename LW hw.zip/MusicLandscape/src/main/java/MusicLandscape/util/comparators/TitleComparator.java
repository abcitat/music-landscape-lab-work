package MusicLandscape.util.comparators;

import java.util.Comparator;

import MusicLandscape.entities.Track;

public class TitleComparator implements Comparator<Track> {

	@Override
	public int compare(Track t1, Track t2) {
		return t1.getTitle().compareTo(t2.getTitle());
	}
	
	public String toString() {
		return "by title";
	}
}
