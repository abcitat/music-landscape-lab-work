package MusicLandscape.util.comparators;

import java.util.Comparator;

import MusicLandscape.entities.Track;

public class WriterComparator implements Comparator<Track> {

	@Override
	public int compare(Track t1, Track t2) {
		return t1.getWriter().compareTo(t2.getWriter());
	}
	
	public String toString() {
		return "by writer";
	}

}
