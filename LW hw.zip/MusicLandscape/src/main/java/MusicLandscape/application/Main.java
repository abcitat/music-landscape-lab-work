package MusicLandscape.application;

public class Main extends MainProvided {

}

