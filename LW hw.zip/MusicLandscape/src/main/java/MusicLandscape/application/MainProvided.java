// **************************************************
//		
//       git.rev = ${gitrev}
//  git.revision = ${gitrevision}
//         stage = ${stage}
//
// ***************************************************
package MusicLandscape.application;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;

import MusicLandscape.container.MyTrackContainer;
import MusicLandscape.entities.Track;
import MusicLandscape.util.MyFormatter;
import MusicLandscape.util.MyMatcher;
import MusicLandscape.util.comparators.DurationComparator;
import MusicLandscape.util.comparators.PerformerComparator;
import MusicLandscape.util.comparators.TitleComparator;
import MusicLandscape.util.comparators.WriterComparator;
import MusicLandscape.util.comparators.YearComparator;
import MusicLandscape.util.formatters.CSVTrackFormatter;
import MusicLandscape.util.formatters.LongTrackFormatter;
import MusicLandscape.util.formatters.ShortTrackFormatter;
import MusicLandscape.util.matcher.DurationMatcher;
import MusicLandscape.util.matcher.TitleMatcher;
import MusicLandscape.util.io.MyWriter;
import MusicLandscape.util.io.MyTrackCSVReader;
import MusicLandscape.entities.Artist;

/**
 * 
 * @author TeM
 * @version ${gitrev}
 * @Stage ${stage}
 *
 */
public class MainProvided {

	private MyTrackContainer db = new MyTrackContainer();
	private List<Comparator<Track>> comparators = new LinkedList<Comparator<Track>>();
	private List<MyFormatter<Track>> formatters = new LinkedList<MyFormatter<Track>>();
	private List<MyMatcher<Track>> matchers = new LinkedList<MyMatcher<Track>>();

	private Comparator<Track> theComp;
	private boolean asc = true;

	private MyFormatter<Track> theFormat;
	private MyMatcher<Track> placeboMatcher = new TitleMatcher("");
	private Menu menu = new Menu();

	{

		comparators.add(theComp = new TitleComparator());
		comparators.add(new DurationComparator());
		comparators.add(new WriterComparator());
		comparators.add(new PerformerComparator());
		comparators.add(new YearComparator());

		matchers.add(placeboMatcher);
		matchers.add(new DurationMatcher());

		formatters.add(theFormat = new LongTrackFormatter());
		formatters.add(new ShortTrackFormatter());
		formatters.add(new CSVTrackFormatter());

	}

	private static final String WELCOME_TEXT = "Welcome to the FinalTrackDataBase";
	private static final String GOOD_BYE_TEXT = "Thank you for using FinalTrackDataBase";

	private static abstract class MenuItem {
		String text;
		static int nextID = 0;
		final int id = nextID++;

		abstract void execute();

		MenuItem(String s) {
			text = s;
		};

		public String toString() {
			return id + "\t" + text;
		}
	}

	private class Menu {

		private MenuItem[] menu = {

		new MenuItem("show menu") {
			void execute() {
				display();
			}
		// end of MenuItem 0 show menu
		},

		new MenuItem("display selection") {
			void execute() {
				System.out.printf("displaying selection:\n");

				MainProvided.this.display(db);
			}
    	// end of MenuItem 1 : display selection
		},
		
		new MenuItem("edit") {
			void execute() {
				System.out.printf("edit:\n");
				
				db.printTracks();
				
				if(db.showTracks().size() != 0){					
					System.out.print("Enter the index: \n");	
					Scanner s=new Scanner(System.in);
					String index =s.nextLine();
					int i=Integer.parseInt(index);
					
					if(i >=0 && i < db.showTracks().size() && db.hasTrack(i))
						System.out.println("\nTrack with index: ["+index+"] has been edited");						
					else
						System.out.println("\nnothing has been edited\n");
			
				}else{
					System.out.println("\nno Tracks in the data base\n");
				}	
			}			    	
		},// end of MenuItem 2 : edit
		
		new MenuItem("filter") {
			void execute() {
				System.out.printf("available filters:\n"
								+"1: title starts with ()\n"
								+"2: duration in range (0 2147483647), args)\n");
				System.out.printf("select filtering\n");
				Scanner sc=new Scanner(System.in);
				try {
					int filterIndex=sc.nextInt();
					if(filterIndex==1 || filterIndex==2) {		
						if(filterIndex <= matchers.size()) {
							placeboMatcher = matchers.get(filterIndex-1);
							if(filterIndex==1){				
								System.out.printf("enter pattern: \n");
								Scanner x = new Scanner(System.in);
								String TitleInfo = x.nextLine();								
								placeboMatcher.setPattern(TitleInfo);
								int TitileNotMatched = db.filter(placeboMatcher);
								System.out.printf(placeboMatcher.toString()
										+" filter applied ("+TitileNotMatched+" records filtered).");		
							}						
							else {	
								System.out.printf("enter duration (\"min max\") in seconds: \n");
								Scanner y = new Scanner(System.in);
								String durationInfo = y.nextLine();	
								placeboMatcher.setPattern(durationInfo);
								int DurationNotMatched = db.filter(placeboMatcher);
								System.out.printf(placeboMatcher.toString()
										+" filter applied ("+DurationNotMatched+" records filtered).");			
							}			
						}						
					}else 
						System.out.printf("Error: The input value should be only 1 or 2.\n");
				}catch(InputMismatchException e) {
					System.out.printf("\nError: The input value should be a number!\n");
				}
				
									
			}					
		},// end of MenuItem 3 : filter
				
		new MenuItem("reset") {	
			void execute() {
				
				if(db.size() > 0){
					//clear selection,add tracks to selection
					db.reset();
					System.out.printf("\nThe selection has been sucessfully reset\n");
				}else
					System.out.printf("\nData Base is empty, reset is not sucessful\n");					
			}					 	
		},// end of MenuItem 4 : reset
		
		new MenuItem("remove selection") {
			void execute() {	
				
				if (db.selection().length == 0) {
					System.out.print("Selection is empty.\n");
				}else {		
					int index = 0;
					Track[] removeSelection = db.selection();
					
					for(Track x:removeSelection){
						System.out.printf("\n"+"[%03d] "+x.toString(), index++);
					}
					System.out.printf("\nEnter the index number:\n");
	
					Scanner sc=new Scanner(System.in);
					int temp=sc.nextInt();
					if(temp<0)
						System.out.printf("\nError: The input is not a valid index");
					else {
						try {
							if (temp>=0 && temp<=index) {
								index=temp;
								Track t = removeSelection[index];
								db.removeFromSelection(t);
								System.out.printf("\nTrack with index ["+index+"] was removed from the selection\n");
							}
						}catch(ArrayIndexOutOfBoundsException e){
							System.out.printf("\nError: Index out of range");
						}
					}
						
				}			
			}
		},// end of MenuItem 5:remove selection
		
		new MenuItem("add") {
			void execute() {
				System.out.printf("add:\n");
				System.out.printf("Enter in the following format:\n"
						+ "Title,Writer,Performer,Duration,Year\n");
				Track newTrack = new Track();
				String userInput = "";	
				Scanner sc=new Scanner(System.in);
				userInput = sc.nextLine();			
				
				try {
					if (userInput!=null) { 
						String[] x=userInput.split(",");
						newTrack=new Track();
						newTrack.setTitle(x[0]);
						newTrack.setWriter(new Artist(x[1]));
						newTrack.setPerformer(new Artist(x[2]));
						newTrack.setDuration(Integer.parseInt(x[3]));
						newTrack.setYear(Integer.parseInt(x[4]));
						newTrack.toString();
					} 			
				} catch (RuntimeException e) {
					System.out.printf(userInput + "Error parsing.");
					e.printStackTrace();
				}		
			
				if(db.add(newTrack) == true){
					System.out.printf("\n New Track: "+ newTrack.toString() +" was added to data base\n");
					db.addToSelection(newTrack);
					System.out.printf("\n New Track: "+ newTrack.toString() +" was added to selection\n");			
				}else{
					System.out.printf("\n New Track: "+ newTrack.toString() +" cannot add to the data base\n");
				}									
			}						
		},// end of MenuItem 6: add
	
		new MenuItem("save selection") {
			void execute() {
				
				String filename = null;
				System.out.printf("enter target file name: \n");
				Scanner sc=new Scanner(System.in);
				filename = sc.nextLine();
				
				try{
					export(filename);				
				} catch ( IOException e) {
					// TODO Auto-generated catch block
					System.out.printf("\n\""+ filename + "\" not found\n");
					e.printStackTrace();
				}	
			}						 	
		}, // end of MenuItem 7: save selection
		
		new MenuItem("load") {
			void execute() {			
				String filename = null;
				System.out.printf("enter target file name: \n");
				Scanner sc=new Scanner(System.in);
				filename = sc.nextLine();		
				try{
					readfile(filename);				
				} catch (FileNotFoundException e) {
					System.out.printf("\n\"Error: cannot open file ("+filename+").\n");
					e.printStackTrace();
				}
			}							
		},// end of MenuItem 8: load
		
		new MenuItem("reverse sorting order") {
			void execute() {
				if(asc == true){
					asc = false;
					db.sort(theComp, asc);
					System.out.printf("selection sorted "+theComp.toString()+" (descending).\n");					
				}else{
					asc = true;
					db.sort(theComp, asc);
					System.out.printf("selection sorted "+theComp.toString()+" (ascending).\n");
				}			
			}						    	
		},// end of MenuItem 9: reverse sorting order
		
		new MenuItem("select sorting") {
			void execute() {
			
				int count = 1;
				for(Comparator<Track> x:comparators){
					System.out.printf(count++ +": "+x.toString()+"\n");
				}
				System.out.printf("select Sorting: \n");
				Scanner sc=new Scanner(System.in);
				int sortIndex = sc.nextInt();			
								
				if(sortIndex >=1 && sortIndex <= comparators.size() && comparators.get(sortIndex-1) != null){
					theComp = comparators.get(sortIndex-1);
					db.sort(theComp, asc);
					System.out.printf("selection sorted "+theComp.toString()+" (ascending).\n");					
				}else
					System.out.printf("\nError: The input value should be from 1 to 5 \n");
		
			}							
		},// end of MenuItem 10: select sorting
		
		new MenuItem("select formating") {
			void execute() {
								
				int count = 1;
				for(MyFormatter<Track> x:formatters){
					System.out.printf(count++ +": "+x.toString()+"\n");
				}
				System.out.printf("select formatting: \n");
				Scanner sc=new Scanner(System.in);
				int formatIndex = sc.nextInt();	
				
				if(formatIndex >=1 && formatIndex <= formatters.size() && formatters.get(formatIndex-1) != null){			
					theFormat = formatters.get(formatIndex-1);
					System.out.printf("\n the format was changed with format index["+formatIndex+"]\n");
					System.out.printf("%s\n",theFormat.toString());

				}else
					System.out.printf("Error: The input value should be from 1 to 3\n");				
				
			}						 	
		}// end of MenuItem 11: select formating
	
			
		};// end of array

		void display() {
			for (MenuItem m : menu) {
				System.out.println(m);
			}
		}

		public boolean execute(int input) {
			for (MenuItem m : menu) {
				if (m != null && m.id == input) {
					m.execute();
					return true;
				}
			}
			return false;
		}	

		
		void export(String filename) throws IOException{							
			if(filename.trim().length() != 0 && filename != null){	
				BufferedWriter bw = new BufferedWriter(new FileWriter(filename));			
				int count = 0;
				
				for(Track x: db.selection()){
					FileWriter fw = new FileWriter(filename, true);
					MyWriter<Track> fileWriter = new MyWriter<Track>(fw, theFormat);
					
					fileWriter.put(x);				
					count++;
					fileWriter.close();
					fw.close();
				}								
				System.out.printf(count+" Tracks exported sucessfully\n");
				bw.close();
			}					
			
		}
		
		void readfile(String filename) throws FileNotFoundException{
			
			if(filename.trim().length() != 0 && filename != null){

				BufferedReader br = new BufferedReader(new FileReader(filename));
				MyTrackCSVReader toRead = new MyTrackCSVReader(br);
				
				List<Track> toAdd = new ArrayList<Track>();
				Track t = new Track();
				
				while(null != (t = toRead.get())){
					toAdd.add(t);
					System.out.printf(theFormat.format(t)+"\n");	
				}	

				db = new MyTrackContainer(toAdd);
						
				System.out.printf(toAdd.size()+" Tracks imported sucessfully\n");

			}
		}
		
	}

	
	public void go() {

		System.out.println(WELCOME_TEXT);
		Scanner sc = new Scanner(System.in);
		menu.execute(0);
		while (true) {
			// display(db);
			// get choice
			System.out.print(": ");
			int input = Integer.parseInt(sc.nextLine());
			if (menu.execute(input))
				continue;

			System.out.print("exit? (1=yes)");
			if (Integer.parseInt(sc.nextLine()) == 1)
				break;
		}

		System.out.println(GOOD_BYE_TEXT);
		sc.close();
	}


	public static void main(String[] args) {

		new MainProvided().go();

	}

	public void display(MyTrackContainer db) {

		if (db.size() == 0) {
			System.out.print("no records stored.\n");
			return;
		}
		if (db.selection().length == 0) {
			System.out.print("selection is empty.\n");
			return;
		}

		System.out.println('\n' + theFormat.header());
		System.out.println(theFormat.topSeparator());
		for (Track tt : db.selection())
			System.out.println(theFormat.format(tt));
		System.out.println();

		System.out.printf("%d out of %d records selected\n", db.selection().length,
				db.size());
	}

}
