package MusicLandscape;
import MusicLandscape.entities.*;
import MusicLandscape.util.formatters.*;
import MusicLandscape.util.matcher.TitleMatcher;
import MusicLandscape.util.comparators.*;
import MusicLandscape.container.*;
import MusicLandscape.util.io.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.IOException;


public class DemoApp {
	public static void main(String[] args) throws Exception{
		//add artists
		Artist a1 = new Artist();
		a1.setName("Arthur F");
		Artist a2 = new Artist();
		a2.setName("John L");
		Artist a3 = new Artist();
		a3.setName("George M");
		
		//add writers
		Artist w1 = new Artist();
		w1.setName("Nacio H B");	
		Artist w2 = new Artist();
		w2.setName("John L");
		Artist w3 = new Artist();
		w3.setName("George M");
		
		//add track t1
		Track t1 = new Track();
		t1.setTitle("Pretty Boys");
		t1.setDuration(180);
		t1.setPerformer(a1);
		t1.setYear(1929);
		t1.setWriter(w1);
		
		//add track t2
		Track t2 = new Track();
		t2.setTitle("Imagine");
		t2.setDuration(200);
		t2.setPerformer(a2);
		t2.setYear(1975);
		t2.setWriter(w2);
		
		
		//add track t3
		Track t3= new Track();
		t3.setTitle("Christmas");
		t3.setDuration(150);
		t3.setPerformer(a3);
		t3.setYear(1980);
		t3.setWriter(w3);
		
		//try adding event e1
		Event e1=new Event();
		e1.setArtist(a1);
		e1.setAttendees(100);
		Date d1=new Date();
		d1.addDay(0);
		d1.addMonth(2);
		d1.addYear(21);
		e1.setDate(d1);
		e1.setDescription("moderate popular");
		e1.setVenue(null);
		
		//try adding event e2
		Event e2=new Event();
		e2.setArtist(a2);
		e2.setAttendees(250);
		Date d2=new Date();		
		d2.addDay(1);
		d2.addMonth(8);
		d2.addYear(35);
		System.out.print("getYear");
		System.out.print(d2.getYear());
		e2.setDate(d2);
		e2.setDescription("Very popular");
		Venue v2=new Venue();
		v2.setCapacity(1000);
		v2.setName("London");
		e2.setVenue(v2);
		
		//print tracks and events
		System.out.print(t1.toString());
		System.out.print("\n"+t2.toString());
		System.out.print("\n"+t3.toString());
		System.out.print("\n"+e1.toString());
		System.out.print("\n"+e2.toString());
		
		//add album
		Album ab1=new Album();
		ab1.addTrack(t1);
		ab1.addTrack(t2);
		ab1.addTrack(t3);
		
		//use album functions
		System.out.print("\n"+ab1.getTracks());
		System.out.print("\n"+ab1.nrTracks());
		System.out.print("\n"+ab1.totalTime());
		System.out.print("\n"+ab1.toString());
		
		//remove one track of index 1
		ab1.removeTrack(1);
		
		//print to see the effect of removing
		System.out.print("\n"+ab1.getTracks());
		System.out.print("\n"+ab1.nrTracks());
		System.out.print("\n"+ab1.totalTime());
		System.out.print("\n"+ab1.toString());
		
		//add the track t2 again
		ab1.addTrack(t2);
		System.out.print("\n"+ab1.getTracks());
		System.out.print("\n"+ab1.nrTracks());
		System.out.print("\n"+ab1.totalTime());
		System.out.print("\n"+ab1.toString());
		
		// try formatter
		ShortTrackFormatter stf1=new ShortTrackFormatter();
		System.out.print("\n"+stf1.format(t2));
		
		// try comparator
		DurationComparator dc1=new DurationComparator();
		System.out.print("\n"+dc1.compare(t1,t2));
		System.out.print("\n"+dc1.compare(t2,t3));
		
		
		//test MyTrackContainer
		MyTrackContainer tc1=new MyTrackContainer();	
		System.out.print("\n"+tc1.add(t1));
		System.out.print("\n"+tc1.add(t2));
		System.out.print("\n"+tc1.add(t3));	
		System.out.print("\n"+tc1.size());
		System.out.print("\n"+tc1.remove());
		tc1.reset();
		System.out.print("\n"+tc1.addAll(ab1.getTracks()));
		System.out.print("\n"+tc1.size());		
		tc1.printTracks();
		System.out.print("\n"+tc1.showTracks());	
		//System.out.print("\n"+tc1.filter(new TitleMatcher("Ch")));	
		tc1.sort(dc1,false);
		
		//test reading csv
		FileReader f=new FileReader("mytracks.csv");
		BufferedReader br=new BufferedReader(f);
		MyTrackCSVReader trial=new MyTrackCSVReader(br);
		System.out.print("\n"+trial.get());	
		
		/*
		String line;
		while(null!=(line=br.readLine()))
			System.out.println(line);		
		*/
		
		//test writing csv
		CSVTrackFormatter tf1=new CSVTrackFormatter();
		//System.out.print("\n"+tf1.header());	
		//System.out.print("\n"+tf1.format(t1));	
		//System.out.print("\n"+tf1.format(t2));	
		//System.out.print("\n"+tf1.format(t3));	
		
		try {
			BufferedWriter bw=new BufferedWriter(new FileWriter("test.csv"));
			String s1=tf1.format(t1);
			String s2=tf1.format(t2);
			String s3=tf1.format(t3);
			bw.write(s1.toString()+"\n");
			bw.write(s2.toString()+"\n");
			bw.write(s3.toString()+"\n");
			bw.close();
		}
		catch(FileNotFoundException e){
			System.out.println(e);
			
		}
		catch(IOException e){
			System.out.println(e);
			
		}
	}
}
		


