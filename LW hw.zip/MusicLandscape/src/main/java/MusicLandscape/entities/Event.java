package MusicLandscape.entities;


public class Event extends Object{
	
	private Artist artist=new Artist();
	private int attendees=0;
	private MusicLandscape.Date date=null;
	private String description="";
	private MusicLandscape.Venue venue=null;
	
	public Event() {
		
	}
	
	public Event(Event e) {
		this.artist=new Artist(e.artist);
		this.attendees=e.attendees;
		this.date=new MusicLandscape.Date(e.date);
		this.description=e.description;
		this.venue=new MusicLandscape.Venue(e.venue);
	}
	
	public Artist getArtist() {
		return artist;
	}
	
	public int getAttendees() {
		return attendees;
	}

	public MusicLandscape.Date getDate() {
		if(date!=null)
			return new MusicLandscape.Date(date);
		return null;
	}
	
	
	public String getDescription() {
		return description;
	}
	
	
	public MusicLandscape.Venue getVenue() {
		return venue;
	}
	
	public int impact() {
		return attendees*2;
	}
	
	
	public void setArtist(Artist artist) {
		if(artist==null)
			return;
		this.artist=artist;
	}  
	
	
	public void setAttendees(int attendees) {
		if(attendees<0)
			return;
		this.attendees=attendees;
	}
	
	
	public void setDate(MusicLandscape.Date date) {
		if(date==null)
			return;
		this.date=new MusicLandscape.Date(date);
	}  
	
	
	public void setDescription(String description) {
		if(description!=null)
			this.description=description;
	}
	

	public void setVenue(MusicLandscape.Venue venue)  {
		this.venue=venue;
	}
	
	public String toString() {
		return String.format(
			"%s @ %s on %s\n%s\n(%d attending (%d))",
			artist==null?"unknown":artist.getName()==null?"unknown":artist.getName(),
			venue==null?"unknown":venue.getName()==null?"unknown":venue.getName(),
			date==null?null:date.toString()==null?null:date.toString(),
			description==null?"unknown":description,
			attendees,
			impact()
			);
	}

	
}

