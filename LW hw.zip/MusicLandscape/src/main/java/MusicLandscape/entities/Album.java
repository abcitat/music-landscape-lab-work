package MusicLandscape.entities;

public class Album extends Release {
	
	private class TrackListItem {
		Album.TrackListItem next;
		Track track;
		
		TrackListItem(Track t){
			track=t;
		}
	}

	private Album.TrackListItem trackListHead;

	public Album() {
	}

	public Album(Album orig) {
		super(orig);
		this.trackListHead=orig.trackListHead;
	}

	public Album(String title, Artist artist, int year) {
		super(title, artist, year);
	}
	
	public boolean addTrack(Track t) {
		if (t==null)
			return false;
		
		else {	
			if (trackListHead==null) {
				trackListHead=new TrackListItem(t);
				return true;
			}
			else {
				TrackListItem p=trackListHead;	
				while(p.next!=null)
					p=p.next;
				p.next=new TrackListItem(t);
				return true;
			}
		}
	}

	public Track removeTrack(int n) {
		if (trackListHead==null)
			return null;
		
		if (n==0) {
			TrackListItem temp=trackListHead;
			trackListHead=trackListHead.next;
			return temp.track;
		}
		
		else {
			int i=0;
			for (TrackListItem p=trackListHead;p!=null;p=p.next) {
				i++;
				if (i==n) {
					Track temp=p.next.track;
					p.next=p.next.next;
					return temp;
				}
			} 
		} return null;
			
	}
	
	public int nrTracks() {
		int num=0;
		for (TrackListItem p=trackListHead;p!=null;p=p.next)
			num++;
		return num;
	}

	public Track[] getTracks() {
		Track[] array = new Track[nrTracks()];
		int i = 0;
		for (TrackListItem p=trackListHead;p!=null;p=p.next)	
			array[i++] = p.track;
		return array;
	}
	
	@Override	
	public int totalTime() {
		int time = 0;
		for (TrackListItem p = trackListHead; p != null; p = p.next) {
			time+=p.track.getDuration();
		}
		return time;
	}

	@Override
	public String toString() {
		String albumTracks="";
		for (TrackListItem p = trackListHead; p != null; p = p.next) {
			albumTracks=albumTracks+"["+p.track.getTitle()+"]";
		}
		return super.toString() +"\n[" + albumTracks + "]";
	}
}
