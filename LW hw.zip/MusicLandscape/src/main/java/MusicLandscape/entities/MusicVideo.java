package MusicLandscape.entities;

public class MusicVideo extends Release {
	private Track track;
	
	public MusicVideo() {
	}

	public Track getTrack() {
		return track;
	}

	public void setTrack(Track track) {
		this.track = track;
	}
	
	@Override
	public int totalTime() {
		if (track!=null) 
			return track.getDuration();
		return 0;
	}

	@Override
	public String toString() {
		if (super.toString()!=null)
			return super.toString() + "-(Video)";
		return null;
	}

}
