package MusicLandscape.entities;
import java.util.Scanner;
import MusicLandscape.util.ConsoleScanable;

public class Track extends Object implements ConsoleScanable, Comparable<Track> {

	private String title=null;
	private int duration=0;
	private Artist writer=new Artist();
	private Artist performer=new Artist();
	private int year=1900;
	
	public Track() {
	}
	
	public Track(String title) {
		this();
		this.title=title;
	}
	public Track(Track t) {
		this.title=t.title;
		this.duration=t.duration;
		this.writer=new Artist(t.writer);
		this.performer=new Artist(t.performer);
		this.year=t.year;
	}

	public void setYear(int year) {
		if(1900<=year && year<=2999)
			this.year=year;
		return;
	}	
	
	public int getYear() {
		return year;
	}	
	
	public void setDuration(int duration) {
		if(duration>=0)
			this.duration=duration;
		return;
	}
	
	//in second
	public int getDuration() {
		return duration;
	}
	
	public void setTitle(String title) {
		this.title=title;
	}
	
	public String getTitle() {
		if(title==null)
			return "unknown title";
		return title;	
	}
	
	public void setWriter(Artist writer) {
		if(writer==null) 
			return;
		this.writer=writer;
	}	
	
	public Artist getWriter() {
		return writer;
	}
	
	public void setPerformer(Artist performer) {
		if(performer==null)
			return;
		this.performer=performer;
	}
	
	public Artist getPerformer() {
		return performer;
	}
	
	public boolean writerIsKnown() {
		if(writer == null)
			return false;
		if(writer.getName()!=null) 
			return true;
		return false;				

	}
	
	public String getString() {
		return String.format(
				"%10.10s by %10.10s performed by %10.10s (%02d:%02d)",
				title==null?"unknown":title,
				writer==null?"unknown":writer.getName()==null?"unknown":writer.getName(),			
				performer==null?"unknown":performer.getName()==null?"unknown":performer.getName(),
				duration==0?00:duration/60,
				duration==0?00:duration%60);
	}
	
	public String toString() {
		return getString();
	}
	
	@Override
	public boolean scan() {
		Scanner sc = new Scanner(System.in);
		String input;
		boolean fieldChanged = false, objectChanged = false;
		
		do {
			System.out.printf("current title: %s\n", this.title);
			System.out.printf("enter new title (leave empty to keep):");
			input = sc.nextLine();
			if (input.length() == 0) { 
				fieldChanged = false;
				break;
			}
			
			fieldChanged = true;
			break;
		} while (true);
		
		if (fieldChanged) {
			setTitle(input);
		}
		
		objectChanged = objectChanged || fieldChanged;
		fieldChanged = false; 
		
		int new_duration=this.getDuration();
	
		do {
			System.out.printf("current duration: %d\n", this.getDuration());
			System.out.printf("enter new duration (leave empty to keep):");
			input = sc.nextLine();
			if (input.length() == 0) { 
				fieldChanged = false;
				break;
			}
			new_duration = Integer.parseInt(input);

			if (new_duration > 0) {
				fieldChanged = true;
				break;
			}
		} while (true);
		
		if (fieldChanged) {
			this.setDuration(new_duration);
		}
		
		objectChanged = objectChanged || fieldChanged;
		fieldChanged = false; 

		return objectChanged;

	}
	
	@Override
	public int compareTo(Track o) {
		return title.compareTo(o.title);
	}
	
	public static boolean validateYear(int year){	
		if(year > 1900 && year < 2999) 
			return true;
		return false;
		
	}
	
	public static final boolean validateTitle(String title){
		if(title != null) 
			return true;
		return false;
	}
	
	public static boolean validateDuration(int duration){	
		if(duration < 0)
			return true;
		return false;
		
	}
	
}

	

	

