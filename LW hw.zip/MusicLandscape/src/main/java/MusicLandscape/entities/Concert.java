package MusicLandscape.entities;

import java.util.Arrays;

public class Concert extends Event{
	private int nextIdx=0;
	private Track[] setList=new Track[0];

	public Concert() {
	}
	
	public boolean addTrack(Track t){
		if (t != null){
			ensureCapacity(nextIdx);
			setList[nextIdx] = t;
			nextIdx++;
			return true;
		}
		return false;
	}	
	
	private void ensureCapacity(int length){
		if (setList.length==length)
			setList=Arrays.copyOf(setList,++length);
	}
	
	
	public Track[] getSetList(){
		Track[] SetListCopy=new Track[nextIdx];
		for (int i=0;i<nextIdx;i++)
			SetListCopy[i]=new Track(setList[i]);
		return SetListCopy;
	}
	
	
	public void setSetList(Track[] tracks){
		if (tracks!=null){ 
			setList=new Track[tracks.length];
			nextIdx=0;
			for (Track x:tracks){
				if (x!=null)
					setList[nextIdx++]=new Track(x);
			}
		}
	}
	
	public void resetSetList(){
		setList=new Track[0];
		nextIdx=0;
	}
	
	public int nrTracks(){
		return nextIdx;
	}
	
	//in second
	public int duration(){
		int duration=0;
		for (int i=0;i<nextIdx;i++){
			if(setList[i].getDuration()>0)
				duration+=setList[i].getDuration();
		}
		return duration;
	}

	
	public int impact(){
		return getAttendees()*(1+duration()/60/60*2);
	}
	
	
	public String toString(){
		return String.format(
				"%s\n%d tracks played, total duration %02d:%02d.",
				super.toString(),
				nrTracks(),
				duration()/60/60,
				duration()/60%60);
	}
}
