package MusicLandscape.entities;
import MusicLandscape.Date;
import MusicLandscape.Venue;
import MusicLandscape.entities.*;

public class AlbumLauncher extends Object {
	
	public  AlbumLauncher() {
	}
	
	private static void disp(Album a){
		System.out.print("\n"+a.toString());   
	}
	
	public static void main(String[] args) {
		/*
		//add artists
		Artist a1 = new Artist();
		a1.setName("Arthur F");
		Artist a2 = new Artist();
		a2.setName("John L");
		Artist a3 = new Artist();
		a3.setName("George M");
		
		//add writers
		Artist w1 = new Artist();
		w1.setName("Nacio H B");	
		Artist w2 = new Artist();
		w2.setName("John L");
		Artist w3 = new Artist();
		w3.setName("George M");
		
		//add track t1
		Track t1 = new Track();
		t1.setTitle("Pretty Boys");
		t1.setDuration(180);
		t1.setPerformer(a1);
		t1.setYear(1929);
		t1.setWriter(w1);
		
		//add track t2
		Track t2 = new Track();
		t2.setTitle("Imagine");
		t2.setDuration(200);
		t2.setPerformer(a2);
		t2.setYear(1975);
		t2.setWriter(w2);
		
		
		//add track t3
		Track t3= new Track();
		t3.setTitle("Christmas");
		t3.setDuration(150);
		t3.setPerformer(a3);
		t3.setYear(1980);
		t3.setWriter(w3);
		
		//try adding event e1
		Event e1=new Event();
		e1.setArtist(a1);
		e1.setAttendees(100);
		Date d1=new Date();
		d1.addDay(0);
		d1.addMonth(2);
		d1.addYear(21);
		e1.setDate(d1);
		e1.setDescription("moderate popular");
		e1.setVenue(null);
		
		//try adding event e2
		Event e2=new Event();
		e2.setArtist(a2);
		e2.setAttendees(250);
		Date d2=new Date();		
		d2.addDay(1);
		d2.addMonth(8);
		d2.addYear(35);
		System.out.print("getYear");
		System.out.print(d2.getYear());
		e2.setDate(d2);
		e2.setDescription("Very popular");
		Venue v2=new Venue();
		v2.setCapacity(1000);
		v2.setName("London");
		e2.setVenue(v2);
		
		//print tracks and events
		System.out.print(t1.toString());
		System.out.print("\n"+t2.toString());
		System.out.print("\n"+t3.toString());
		System.out.print("\n"+e1.toString());
		System.out.print("\n"+e2.toString());
		
		//add album
		Album ab1=new Album();
		ab1.addTrack(t1);
		ab1.addTrack(t2);
		ab1.addTrack(t3);
		
		//use disp method
		disp(ab1);
		*/
	}

}
